# Last Days of Atlantis Information

## Summary
The Last Days of Atlantis is an official implementation of a tabletop role-playing game system for FoundryVTT. It provides a complete framework for character management, combat, and game mechanics specific to the Last Days of Atlantis RPG.

## Structure
- **modules/**: Core system functionality organized by feature
  - **documents/**: Actor and Item document classes
  - **sheets/**: Character and item sheet implementations
  - **dialogs/**: Dialog implementations for various game mechanics
- **templates/**: Handlebars templates for UI components
  - **sheets/**: Character and item sheet templates
  - **partials/**: Reusable template components
  - **messages/**: Chat message templates
  - **dialogs/**: Dialog UI templates
- **languages/**: Localization files (en, es, fr, ru)
- **packs/**: Compendium packs for game content
- **scripts/**: Utility scripts and hooks

## Language & Runtime
**Language**: JavaScript (ES Modules)
**Runtime**: FoundryVTT (minimum v13, verified v13)
**Build System**: Rollup
**Package Manager**: None specified (likely uses npm)

## Dependencies
**Main Dependencies**:
- rollup-plugin-terser: For JavaScript minification
- FoundryVTT API: Core system integration

## Build & Installation
```bash
# Build the minified JavaScript bundle
rollup -c
```

The system can be installed in FoundryVTT via:
1. The built-in package manager using the manifest URL
2. Manual installation by extracting to the systems directory

## Main Entry Points
**Main Module**: `lastdays.js`
**CSS Entry Point**: `lastdays.css`
**System Initialization**: Occurs in the Hooks.once("init") handler in lastdays.js

## Game System Components
**Actor Types**:
- character
- creature

**Item Types**:
- boon
- consumable
- creature_action
- demon
- equipment
- origin
- spell
- spirit
- weapon

**Sheet Implementations**:
- CharacterSheet
- Garysv1CharacterSheet (default)
- ConsumableSheet
- CreatureActionSheet
- CreatureSheet
- EquipmentSheet
- BoonSheet
- OriginSheet
- DemonSheet
- SpellSheet
- SpiritSheet
- WeaponSheet

## Localization
**Supported Languages**:
- English (en)
- Spanish (es)
- French (fr)
- Russian (ru)

## Compendium Content
**Packs**:
- inventory: Collection of equipment items
- boons: Collection of character abilities/powers

## Special Features
- Custom Handlebars helpers for template rendering
- Background and origin selection system
- Attribute test system
- Combat enhancements
- Stress management system
- Customizable boons