export class ldoaItem extends Item {
    /** @override */
    prepareData() {
        super.prepareData();
    }
}
