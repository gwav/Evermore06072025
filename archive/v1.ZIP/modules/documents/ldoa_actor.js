export class ldoaActor extends Actor {
    /** @override */
    prepareData() {
        super.prepareData();
    }
}
