# The Last Days of Atlantis - Official


This repository contains an official implemementation of The Last Days of Atlantis
for the FoundryVTT.

## Foreword

This work is totally free to use and comes with a very liberal license. That
being said it did take time, effort and skill on my part to work out how to do
it and to put it together.

Thanks in advance.


