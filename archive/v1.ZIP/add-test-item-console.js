// CONSOLE COMMAND: Copy and paste this into your browser console (F12)

(async function() {
    const characterId = "77";
    const character = game.actors.get(characterId);
    
    if (!character) {
        console.error(`❌ Character '${characterId}' not found. Available characters:`);
        game.actors.filter(a => a.type === "character").forEach(a => console.log(`- ${a.name} (ID: ${a.id})`));
        return;
    }
    
    const testItem = {
        name: "Test Item",
        type: "equipment", 
        system: {
            description: "Test item for inventory verification",
            quantity: 1,
            cost: 0,
            rarity: "common",
            armorValue: 0
        }
    };
    
    const created = await character.createEmbeddedDocuments("Item", [testItem]);
    console.log(`✅ Added "${created[0].name}" to ${character.name}`);
    console.log(`📊 Character now has ${character.items.size} items total`);
    console.log(`🎒 Equipment: ${character.items.filter(i => i.type === "equipment").length} items`);
    
    if (character.sheet?.rendered) {
        character.sheet.render(false);
        console.log(`🔄 Character sheet refreshed`);
    }
    
    ui.notifications.info(`Test item added! Check the Equipment tab on ${character.name}'s sheet.`);
})();